<?php
require __DIR__ . '/vendor/autoload.php';
new EStar\Loader;