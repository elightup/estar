<?php
if ( EStar\Layout::has_sidebar() ) {
	EStar\Layout::output_sidebar( 'sidebar-1' );
}
