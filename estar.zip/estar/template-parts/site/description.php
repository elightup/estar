<?php if ( get_bloginfo( 'description' ) || is_customize_preview() ) : ?>
	<div class="site-description"><?php bloginfo( 'description' ) ?></div>
<?php endif ?>